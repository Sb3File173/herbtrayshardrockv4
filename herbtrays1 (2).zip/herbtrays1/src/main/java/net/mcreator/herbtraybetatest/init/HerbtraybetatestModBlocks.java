
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.herbtraybetatest.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.herbtraybetatest.block.EmptyherbtraywallBlock;
import net.mcreator.herbtraybetatest.block.EmptyherbtrayfloorBlock;
import net.mcreator.herbtraybetatest.block.DirtHerbtraywallBlock;
import net.mcreator.herbtraybetatest.block.DirtHerbtrayfloorBlock;
import net.mcreator.herbtraybetatest.HerbtraybetatestMod;

public class HerbtraybetatestModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, HerbtraybetatestMod.MODID);
	public static final RegistryObject<Block> EMPTYHERBTRAYFLOOR = REGISTRY.register("emptyherbtrayfloor", () -> new EmptyherbtrayfloorBlock());
	public static final RegistryObject<Block> DIRT_HERBTRAYFLOOR = REGISTRY.register("dirt_herbtrayfloor", () -> new DirtHerbtrayfloorBlock());
	public static final RegistryObject<Block> EMPTYHERBTRAYWALL = REGISTRY.register("emptyherbtraywall", () -> new EmptyherbtraywallBlock());
	public static final RegistryObject<Block> DIRT_HERBTRAYWALL = REGISTRY.register("dirt_herbtraywall", () -> new DirtHerbtraywallBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
